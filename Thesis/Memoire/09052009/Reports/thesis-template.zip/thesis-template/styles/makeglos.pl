%%
%% This is file `makeglos.pl',
%% generated with the docstrip utility.
%%
%% The original source files were:
%%
%% glossary.dtx  (with options: `makeglos.pl,package')
%% Copyright (C) 2005 Nicola Talbot, all rights reserved.
%% If you modify this file, you must change its name first.
%% You are NOT ALLOWED to distribute this file alone. You are NOT
%% ALLOWED to take money for the distribution or use of either this
%% file or a changed version, except for a nominal charge for copying
%% etc.
%% \CharacterTable
%%  {Upper-case    \A\B\C\D\E\F\G\H\I\J\K\L\M\N\O\P\Q\R\S\T\U\V\W\X\Y\Z
%%   Lower-case    \a\b\c\d\e\f\g\h\i\j\k\l\m\n\o\p\q\r\s\t\u\v\w\x\y\z
%%   Digits        \0\1\2\3\4\5\6\7\8\9
%%   Exclamation   \!     Double quote  \"     Hash (number) \#
%%   Dollar        \$     Percent       \%     Ampersand     \&
%%   Acute accent  \'     Left paren    \(     Right paren   \)
%%   Asterisk      \*     Plus          \+     Comma         \,
%%   Minus         \-     Point         \.     Solidus       \/
%%   Colon         \:     Semicolon     \;     Less than     \<
%%   Equals        \=     Greater than  \>     Question mark \?
%%   Commercial at \@     Left bracket  \[     Backslash     \\
%%   Right bracket \]     Circumflex    \^     Underscore    \_
%%   Grave accent  \`     Left brace    \{     Vertical bar  \|
%%   Right brace   \}     Tilde         \~}
#!/usr/bin/perl

# File : makeglos
# Author : Nicola Talbot
# Description: simple Perl script that calls makeindex.
# Intended for use with "glossary.sty" (saves having to remember all the various switches)

# usage : makeglos <filename>

if ($#ARGV != 0)
{
   die "Syntax : $0 <filename>\n";
}

# first check whether .glo extension has been specified:

if (length(@ARGV[0]) < 4)
{
   $name = @ARGV[0];
}
elsif (substr(@ARGV[0],-4,4) eq ".glo")
{
  $name = substr(@ARGV[0],0,length(@ARGV[0])-4);
}
else
{
   $name = @ARGV[0];
}

print "makeindex -s $name.ist -t $name.glg -o $name.gls @ARGV[0]\n";
print `makeindex -s $name.ist -t $name.glg -o $name.gls @ARGV[0]`;

1;
\endinput
%%
%% End of file `makeglos.pl'.
